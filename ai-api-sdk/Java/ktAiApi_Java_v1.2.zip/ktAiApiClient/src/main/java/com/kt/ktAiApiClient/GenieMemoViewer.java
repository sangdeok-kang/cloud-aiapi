package com.kt.ktAiApiClient;

import static javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER;
import static javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED;
import static javax.swing.SwingConstants.CENTER;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import org.json.JSONObject;

import kt.gigagenie.ai.api.GENIEMEMO;

public class GenieMemoViewer extends JFrame {
	private JPanel panelMain;
	private JLabel mainLabel;
	private JProgressBar progressBar;
	private JButton startGenieMemoButton;
	private JButton startQueryButton;
	private JTextArea taskOutput;
	private JScrollPane scrollPane;

	private JComboBox callindexList;
	private JComboBox lastYnList;
	private JComboBox selectList;

	private JLabel callindexLbl;
	private JLabel callKeyLbl;
	private JLabel lastYnLbl;

	private JTextField callKeyText;
	private JLabel fileSelectLbl;
	private JFileChooser fileChooser;

	private File targetFile = null;
	private int sttModeOperation = 1;
	private GENIEMEMO mgeniememo = null;

	public GenieMemoViewer() {
		super("GenieMemo API DEMO");

		createUIComponents();

		JComponent newContentPane = panelMain;
		newContentPane.setOpaque(true); // content panes must be opaque
		setContentPane(newContentPane);

		setResizable(false);
		setMinimumSize(new Dimension(800, 600));
		setSize(800, 600);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent wEvent) {
				if (mgeniememo != null) {
					mgeniememo = null;
				}
				System.exit(0);
			}
		});
		pack();
		setVisible(true);

		if (mgeniememo == null) {
			mgeniememo = new GENIEMEMO();
			String strUrl = "https://" + ENV.hostname + ":" + ENV.ai_api_http_port;
			mgeniememo.setServiceURL(strUrl);
			mgeniememo.setAuth(ENV.client_key, ENV.client_id, ENV.client_secret);
		}
	}

	/**
	 * Create the GUI and show it. As with all GUI code, this must run on the event-dispatching thread.
	 */
	private static void createAndShowGUI() {
		// Create and set up the window.
		GenieMemoViewer viewer = new GenieMemoViewer();
	}

	public static void main(String[] args) {
		// Schedule a job for the event-dispatching thread:
		// creating and showing this application's GUI.
		SwingUtilities.invokeLater(() -> {
			createAndShowGUI();
		});
	}

	private void createUIComponents() {
		// Create the demo's UI.
		panelMain = new JPanel();
		fileChooser = new JFileChooser();

		mainLabel = new JLabel("GenieMemo API DEMO");
		mainLabel.setSize(50, 50);
		mainLabel.setHorizontalAlignment(CENTER);

		taskOutput = new JTextArea(5, 20);
		taskOutput.setMargin(new Insets(5, 5, 5, 5));
		taskOutput.setEditable(false);
		taskOutput.setCursor(null); // inherit the panel's cursor
		taskOutput.setLineWrap(true);

		scrollPane = new JScrollPane(taskOutput, VERTICAL_SCROLLBAR_AS_NEEDED, HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane.setAutoscrolls(true);

		JPanel controlPanel = new JPanel();
		controlPanel.setLayout(new GridLayout(16, 1));

		fileSelectLbl = new JLabel("Select File", JLabel.CENTER);
		fileSelectLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

		JButton fileButton = new JButton("Open...");
		fileButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				int returnVal = fileChooser.showOpenDialog(GenieMemoViewer.this);

				if (returnVal == JFileChooser.APPROVE_OPTION) {
					targetFile = fileChooser.getSelectedFile();
					// This is where a real application would open the file.
					fileSelectLbl.setText("File [" + targetFile.getName() + "]");
				} else {

				}
			}
		});

		controlPanel.add(fileSelectLbl);
		controlPanel.add(fileButton);

		String[] selectStrings = { "GenieMemo", "GeniememoAYNC" };

		JLabel selectLbl = new JLabel("select", JLabel.CENTER);
		selectLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

		selectList = new JComboBox(selectStrings);
		selectList.setSelectedIndex(0);
		selectList.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				JComboBox cb = (JComboBox) e.getSource();
				if (cb.getSelectedIndex() == 1) {
					lastYnLbl.setVisible(false);
					callindexLbl.setVisible(false);
					callindexList.setVisible(false);
					lastYnList.setVisible(false);
				} else {
					lastYnLbl.setVisible(true);
					callindexLbl.setVisible(true);
					callindexList.setVisible(true);
					lastYnList.setVisible(true);
				}
			}
		});

		controlPanel.add(selectLbl);
		controlPanel.add(selectList);

		String[] lastYn = { "Y", "N" };

		lastYnLbl = new JLabel("LastYn", JLabel.CENTER);
		lastYnLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

		lastYnList = new JComboBox(lastYn);
		lastYnList.setSelectedIndex(0);

		controlPanel.add(lastYnLbl);
		controlPanel.add(lastYnList);

		String[] callindexStrings = { "0" };

		callindexLbl = new JLabel("callindex", JLabel.CENTER);
		callindexLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

		callindexList = new JComboBox(callindexStrings);
		callindexList.setSelectedIndex(0);

		controlPanel.add(callindexLbl);
		controlPanel.add(callindexList);

		callKeyLbl = new JLabel("Call Key", JLabel.CENTER);
		callKeyLbl.setAlignmentX(Component.CENTER_ALIGNMENT);
		callKeyLbl.setVisible(true);

		callKeyText = new JTextField(50);
		callKeyText.setVisible(true);

		controlPanel.add(callKeyLbl);
		controlPanel.add(callKeyText);

		controlPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		controlPanel.setPreferredSize(new Dimension(300, 300));

		startGenieMemoButton = new JButton("GenieMemo Request");
		startGenieMemoButton.setActionCommand("start");
		startGenieMemoButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				mgeniememo.setAuth(ENV.client_key, ENV.client_id, ENV.client_secret);
				if (targetFile == null) {
					JOptionPane.showMessageDialog(panelMain, "전송할 파일을 선택 후 요청해주세요.", "Warning", JOptionPane.WARNING_MESSAGE);
					return;
				}
				String input = callKeyText.getText();
				if (input.length() <= 0) {
					JOptionPane.showMessageDialog(panelMain, "callkey를 입력 후 요청해주세요.", "Warning", JOptionPane.WARNING_MESSAGE);
					return;
				}

				progressBar.setVisible(true);
				taskOutput.setText("");

				String callKey = (String) callKeyText.getText();
				int callIndex = 0;
				String selectAYNC = (String) selectList.getSelectedItem();
				String lastYn;
				if (selectAYNC == "GenieMemo") {
					lastYn = (String) lastYnList.getSelectedItem();
				} else {
					lastYn = "";
				}

				SendAudioFile(callKey, lastYn, callIndex, selectAYNC);

				startGenieMemoButton.setEnabled(false);
				startQueryButton.setEnabled(false);
			}
		});

		startQueryButton = new JButton("GenieMemo Query");
		startQueryButton.setActionCommand("start");
		startQueryButton.setEnabled(true);
		startQueryButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				mgeniememo.setAuth(ENV.client_key, ENV.client_id, ENV.client_secret);
				String input = callKeyText.getText();
				if (input.length() <= 0) {
					JOptionPane.showMessageDialog(panelMain, "callkey를 입력 후 요청해주세요.", "Warning", JOptionPane.WARNING_MESSAGE);
					return;
				}
				progressBar.setVisible(true);
				taskOutput.setText("");
				queryGenieMemo(input);
				startGenieMemoButton.setEnabled(false);
				startQueryButton.setEnabled(false);
			}
		});

		progressBar = new JProgressBar();
		progressBar.setIndeterminate(true);
		progressBar.setVisible(false);

		JPanel bottomPanel = new JPanel();
		bottomPanel.add(startGenieMemoButton);
		bottomPanel.add(progressBar);
		bottomPanel.add(startQueryButton);

		panelMain.setLayout(new BorderLayout());
		panelMain.add(mainLabel, BorderLayout.NORTH);
		panelMain.add(scrollPane, BorderLayout.CENTER);
		panelMain.add(controlPanel, BorderLayout.EAST);
		panelMain.add(bottomPanel, BorderLayout.SOUTH);
		panelMain.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
	}

	private void SendAudioFile(final String callKey, final String lastYn, final int callIndex, final String selectAYNC) {
		new Thread(new Runnable() {
			@Override
			public void run() {
				try {
					byte[] uploadAudioByte = null;

					FileInputStream inputStream = new FileInputStream(targetFile);
					ByteArrayOutputStream bos = new ByteArrayOutputStream();
					byte[] buffer = new byte[1024];
					int bytesRead = 0;
					while ((bytesRead = inputStream.read(buffer)) != -1) {
						bos.write(buffer, 0, bytesRead);
					}
					uploadAudioByte = bos.toByteArray();

					inputStream.close();
					bos.close();

					JSONObject resultJson = mgeniememo.requestGenieMemo(uploadAudioByte, callKey, lastYn, callIndex, selectAYNC);

					requestGenieMemoResponse(resultJson);
					startGenieMemoButton.setEnabled(true);
					startQueryButton.setEnabled(true);

				} catch (Exception e) {
					progressBar.setVisible(false);
					startGenieMemoButton.setEnabled(true);
					if (sttModeOperation == 1)
						startQueryButton.setEnabled(false);
					else
						startQueryButton.setEnabled(true);
					JOptionPane.showMessageDialog(panelMain, "GenieMemo 요청 중 에러가 발생하였습니다.", "Warning", JOptionPane.WARNING_MESSAGE);
				}
			}
		}).start();
	}

	private void requestGenieMemoResponse(JSONObject resultJson) {
		try {
			int statusCode = resultJson.optInt("statusCode");
			if (statusCode == 200) {
				String result = resultJson.optString("result");
				taskOutput.setText(result);
				progressBar.setVisible(false);
				JOptionPane.showMessageDialog(panelMain, "완료되었습니다.", "Message", JOptionPane.INFORMATION_MESSAGE);
			} else {
				String result = resultJson.toString();
				taskOutput.setText(result);
				progressBar.setVisible(false);
				JOptionPane.showMessageDialog(panelMain, "Geniememo 요청 중 에러가 발생하였습니다.", "Warning", JOptionPane.WARNING_MESSAGE);
			}
		} catch (Exception e) {
			progressBar.setVisible(false);
			JOptionPane.showMessageDialog(panelMain, "Geniememo 요청 중 에러가 발생하였습니다.", "Warning", JOptionPane.WARNING_MESSAGE);
		}
	}

	private void queryGenieMemo(final String callkey) {
		new Thread(new Runnable() {
			@Override
			public void run() {
				JSONObject resultJson = mgeniememo.queryGenieMemo(callkey);
				queryGenieMemoResponse(resultJson);
			}
		}).start();
	}

	private void queryGenieMemoResponse(JSONObject resultJson) {
		try {
			int statusCode = resultJson.optInt("statusCode");

			if (statusCode == 200) {
				String resultquery = resultJson.optString("result");

				taskOutput.setText(resultquery);
				progressBar.setVisible(false);
				startGenieMemoButton.setEnabled(true);
				startQueryButton.setEnabled(true);
				JOptionPane.showMessageDialog(panelMain, "완료되었습니다.", "Message", JOptionPane.INFORMATION_MESSAGE);
			} else {
				String resultquery = resultJson.toString();

				taskOutput.setText(resultquery);
				progressBar.setVisible(false);
				startGenieMemoButton.setEnabled(true);
				startQueryButton.setEnabled(true);
				JOptionPane.showMessageDialog(panelMain, "완료되었습니다.", "Message", JOptionPane.INFORMATION_MESSAGE);
			}
		} catch (Exception e) {
			progressBar.setVisible(false);
			startGenieMemoButton.setEnabled(true);
			if (sttModeOperation == 1)
				startQueryButton.setEnabled(false);
			else
				startQueryButton.setEnabled(true);
			JOptionPane.showMessageDialog(panelMain, "GenieMemo 마지막 catch 요청 중 에러가 발생하였습니다.", "Warning", JOptionPane.WARNING_MESSAGE);
		}
	}
}
