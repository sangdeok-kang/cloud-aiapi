package com.kt.ktAiApiClient;

import static javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER;
import static javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED;
import static javax.swing.SwingConstants.CENTER;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import org.json.JSONArray;
import org.json.JSONObject;

import kt.gigagenie.ai.api.STT;

public class Stt2RestViewer extends JFrame {
	private JPanel panelMain;
	private JLabel mainLabel;
	private JProgressBar progressBar;
	private JButton startSTTAdButton;
	private JButton startQueryButton;
	private JTextArea taskOutput;
	private JScrollPane scrollPane;

	private JComboBox encodingList;
	private JComboBox sttModelcodeList;

	private JLabel transactionLbl;
	private JLabel sttModelcodeLbl;

	private JTextField transactionIdText;
	private JLabel fileSelectLbl;
	private JFileChooser fileChooser;

	private File targetFile = null;
	private String mTransactionId;
	private STT mStt = null;

	/** STT Ad voice Recognize URL */
	private final String URL_STT_Ad_VOICE_RECOGNIZER = "/v2/voiceRecognize2";

	public Stt2RestViewer() {
		super("STT Rest API DEMO");

		createUIComponents();

		JComponent newContentPane = panelMain;
		newContentPane.setOpaque(true); // content panes must be opaque
		setContentPane(newContentPane);

		setResizable(false);
		setMinimumSize(new Dimension(800, 600));
		setSize(800, 600);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent wEvent) {
				if (mStt != null) {
					mStt = null;
				}
				System.exit(0);
			}
		});
		pack();
		setVisible(true);

		if (mStt == null) {
			mStt = new STT();
			String strUrl = "https://" + ENV.hostname + ":" + ENV.ai_api_http_port;
			mStt.setServiceURL(strUrl);
			mStt.setAuth(ENV.client_key, ENV.client_id, ENV.client_secret);
		}
	}

	/**
	 * Create the GUI and show it. As with all GUI code, this must run on the event-dispatching thread.
	 */
	private static void createAndShowGUI() {
		// Create and set up the window.
		Stt2RestViewer viewer = new Stt2RestViewer();
	}

	public static void main(String[] args) {
		// Schedule a job for the event-dispatching thread:
		// creating and showing this application's GUI.
		SwingUtilities.invokeLater(() -> {
			createAndShowGUI();
		});
	}

	private void createUIComponents() {
		// Create the demo's UI.
		panelMain = new JPanel();
		fileChooser = new JFileChooser();

		mainLabel = new JLabel("STT Rest API DEMO");
		mainLabel.setSize(50, 50);
		mainLabel.setHorizontalAlignment(CENTER);

		taskOutput = new JTextArea(5, 20);
		taskOutput.setMargin(new Insets(5, 5, 5, 5));
		taskOutput.setEditable(false);
		taskOutput.setCursor(null); // inherit the panel's cursor
		taskOutput.setLineWrap(true);

		scrollPane = new JScrollPane(taskOutput, VERTICAL_SCROLLBAR_AS_NEEDED, HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane.setAutoscrolls(true);

		JPanel controlPanel = new JPanel();
		controlPanel.setLayout(new GridLayout(16, 1));

		fileSelectLbl = new JLabel("Select File", JLabel.CENTER);
		fileSelectLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

		JButton fileButton = new JButton("Open...");
		fileButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				int returnVal = fileChooser.showOpenDialog(Stt2RestViewer.this);

				if (returnVal == JFileChooser.APPROVE_OPTION) {
					targetFile = fileChooser.getSelectedFile();
					// This is where a real application would open the file.
					fileSelectLbl.setText("File [" + targetFile.getName() + "]");
				} else {

				}
			}
		});

		controlPanel.add(fileSelectLbl);
		controlPanel.add(fileButton);

		String[] encodingStrings = { "raw", "wav", "mp3", "vor", "aac", "fla" };

		JLabel encodingLbl = new JLabel("encoding", JLabel.CENTER);
		encodingLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

		encodingList = new JComboBox(encodingStrings);
		encodingList.setSelectedIndex(0);

		controlPanel.add(encodingLbl);
		controlPanel.add(encodingList);

		transactionLbl = new JLabel("transaction Id", JLabel.CENTER);
		transactionLbl.setAlignmentX(Component.CENTER_ALIGNMENT);
		transactionLbl.setVisible(false);

		transactionIdText = new JTextField(50);
		transactionIdText.setVisible(false);

		controlPanel.add(transactionLbl);
		controlPanel.add(transactionIdText);

		String[] sttModlecodeStrings = { "3", "4", "5" };

		sttModelcodeLbl = new JLabel("sttModlecode", JLabel.CENTER);
		sttModelcodeLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

		sttModelcodeList = new JComboBox(sttModlecodeStrings);
		sttModelcodeList.setSelectedIndex(0);
		sttModelcodeList.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				JComboBox cb = (JComboBox) e.getSource();
				if (cb.getSelectedIndex() == 0) {
					transactionLbl.setVisible(false);
					transactionIdText.setVisible(false);
				} else {
					transactionLbl.setVisible(true);
					transactionIdText.setVisible(true);
				}
			}
		});
		controlPanel.add(sttModelcodeLbl);
		controlPanel.add(sttModelcodeList);

		controlPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		controlPanel.setPreferredSize(new Dimension(300, 300));

		startSTTAdButton = new JButton("STT Request");
		startSTTAdButton.setActionCommand("start");
		startSTTAdButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (targetFile == null) {
					JOptionPane.showMessageDialog(panelMain, "전송할 파일을 선택 후 요청해주세요.", "Warning", JOptionPane.WARNING_MESSAGE);
					return;
				}

				progressBar.setVisible(true);
				taskOutput.setText("");

				String encoding = (String) encodingList.getSelectedItem();
				int sttModlecode = Integer.parseInt((String) sttModelcodeList.getSelectedItem());
				SendAudioFile(encoding, sttModlecode);
				startSTTAdButton.setEnabled(false);
				startQueryButton.setEnabled(false);
			}
		});

		startQueryButton = new JButton("STT Query");
		startQueryButton.setActionCommand("start");
		startQueryButton.setEnabled(false);
		startQueryButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String input = transactionIdText.getText();
				if (input.length() <= 0) {
					JOptionPane.showMessageDialog(panelMain, "transactionId를 입력 후 요청해주세요.", "Warning", JOptionPane.WARNING_MESSAGE);
					return;
				}
				progressBar.setVisible(true);
				queryStt(input);
				startQueryButton.setEnabled(false);
			}
		});

		progressBar = new JProgressBar();
		progressBar.setIndeterminate(true);
		progressBar.setVisible(false);

		JPanel bottomPanel = new JPanel();
		bottomPanel.add(startSTTAdButton);
		bottomPanel.add(progressBar);
		bottomPanel.add(startQueryButton);

		panelMain.setLayout(new BorderLayout());
		panelMain.add(mainLabel, BorderLayout.NORTH);
		panelMain.add(scrollPane, BorderLayout.CENTER);
		panelMain.add(controlPanel, BorderLayout.EAST);
		panelMain.add(bottomPanel, BorderLayout.SOUTH);
		panelMain.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
	}

	private void SendAudioFile(final String encoding, final int sttModelCode) {
		new Thread(new Runnable() {
			@Override
			public void run() {
				try {
					byte[] uploadAudioByte = null;

					FileInputStream inputStream = new FileInputStream(targetFile);
					ByteArrayOutputStream bos = new ByteArrayOutputStream();
					byte[] buffer = new byte[1024];
					int bytesRead = 0;
					while ((bytesRead = inputStream.read(buffer)) != -1) {
						bos.write(buffer, 0, bytesRead);
					}
					uploadAudioByte = bos.toByteArray();

					inputStream.close();
					bos.close();

					JSONObject resultJson = mStt.requestSTT2(uploadAudioByte, encoding, sttModelCode);

					requestSttResponse(resultJson);
				} catch (Exception e) {
					progressBar.setVisible(false);
					startSTTAdButton.setEnabled(true);
					JOptionPane.showMessageDialog(panelMain, "STT로 변환요청 중 에러가 발생하였습니다.", "Warning", JOptionPane.WARNING_MESSAGE);
				}
			}
		}).start();
	}

	private void requestSttResponse(JSONObject resultJson) {
		try {
			int statusCode = resultJson.optInt("statusCode");
			if (statusCode == 200) {
				boolean msgReceived = false;
				StringBuilder sb = new StringBuilder();

				String result = resultJson.optString("result");
				JSONArray resultArray = new JSONArray(result);
				for (int i = 0; i < resultArray.length(); i++) {
					JSONObject jsonObject = resultArray.getJSONObject(i);

					if (!jsonObject.isNull("resultType")) {
						String resultType = jsonObject.getString("resultType");

						if (resultType.equalsIgnoreCase("start")) {
							mTransactionId = jsonObject.getString("transactionId");
							int sttModlecode = Integer.parseInt((String) sttModelcodeList.getSelectedItem());
							if (sttModlecode != 3) {
								transactionIdText.setText(mTransactionId);
								taskOutput.setText("해당 Transaction Id로 조회해주세요.");
								progressBar.setVisible(false);
								startQueryButton.setEnabled(true);
							}
						} else if (resultType.equalsIgnoreCase("text")) {
							JSONObject sttResult = jsonObject.getJSONObject("sttResult");
							String text = sttResult.getString("text");
							msgReceived = true;
							sb.append(text).append("\n");
						} else if (resultType.equalsIgnoreCase("end")) {
							JSONObject sttInfoJson = jsonObject.getJSONObject("sttInfo");
						} else if (resultType.equalsIgnoreCase("err")) {
							String errCode = jsonObject.getString("errCode");
							String errMsg = "";

							if (errCode.equalsIgnoreCase("STT000")) {
								errMsg = "허용 음성데이터 용량초과";
							} else if (errCode.equalsIgnoreCase("STT001")) {
								errMsg = "Rest-API Key 사용 정책 설정시 월 API 사용량 한도 초과";
							} else if (errCode.equalsIgnoreCase("STT002")) {
								errMsg = "오디오 포맷 판별 실패, Resampling 실패";
							} else if (errCode.equalsIgnoreCase("STT003")) {
								errMsg = "비동기식 장문 음성 데이터 포맷 에러";
							}

							progressBar.setVisible(false);
							JOptionPane.showMessageDialog(panelMain, "STT 고도화로 변환요청 중 에러가 발생하였습니다.\r\n" + "errCode:" + errCode + ", errMsg:" + errMsg, "Warning", JOptionPane.WARNING_MESSAGE);
						}
					}
				}

				if (msgReceived) {
					progressBar.setVisible(false);
					startSTTAdButton.setEnabled(true);
					taskOutput.setText(sb.toString());
					JOptionPane.showMessageDialog(panelMain, "Text로 변환이 완료되었습니다.", "Message", JOptionPane.INFORMATION_MESSAGE);
				}
			} else {
				String errorCode = resultJson.optString("errorCode");

				progressBar.setVisible(false);
				startSTTAdButton.setEnabled(true);
				JOptionPane.showMessageDialog(panelMain, "statusCode:" + statusCode + ", errorCode:" + errorCode + ", STT로 변환요청 중 에러가 발생하였습니다.", "Warning", JOptionPane.WARNING_MESSAGE);
			}
		} catch (Exception e) {
			progressBar.setVisible(false);
			JOptionPane.showMessageDialog(panelMain, "STT 고도화로 변환요청 중 에러가 발생하였습니다.", "Warning", JOptionPane.WARNING_MESSAGE);
		}
	}

	private void queryStt(final String transactionId) {
		new Thread(new Runnable() {
			@Override
			public void run() {

				JSONObject resultJson = mStt.querySTT(transactionId);
				querySttResponse(resultJson);

			}
		}).start();
	}

	private void querySttResponse(JSONObject resultJson) {
		try {
			int statusCode = resultJson.optInt("statusCode");

			if (statusCode == 200) {
				StringBuilder sb = new StringBuilder();
				String sttStatus = resultJson.getString("sttStatus");

				if (sttStatus.equalsIgnoreCase("processing")) {
					progressBar.setVisible(false);
					startQueryButton.setEnabled(true);
					JOptionPane.showMessageDialog(panelMain, "요청한 Transaction 은 아직 처리중입니다. 다시 조회해주세요.", "Message", JOptionPane.INFORMATION_MESSAGE);
				} else if (sttStatus.equalsIgnoreCase("completed")) {
					JSONArray textArray = resultJson.getJSONArray("sttResults");
					for (int i = 0; i < textArray.length(); i++) {
						JSONObject textJson = textArray.getJSONObject(i);

						String text = textJson.getString("text");
						sb.append(text).append("\n");
					}

					progressBar.setVisible(false);
					taskOutput.setText(sb.toString());
					startSTTAdButton.setEnabled(true);
					startQueryButton.setEnabled(true);
					JOptionPane.showMessageDialog(panelMain, "Text로 변환이 완료되었습니다.", "Message", JOptionPane.INFORMATION_MESSAGE);
				} else if (sttStatus.equalsIgnoreCase("err")) {
					progressBar.setVisible(false);
					startSTTAdButton.setEnabled(true);
					JOptionPane.showMessageDialog(panelMain, "sttStatus:err" + ", STT 고도화로 변환요청 중 에러가 발생하였습니다.", "Warning", JOptionPane.WARNING_MESSAGE);
				}
			} else {
				String errorCode = resultJson.optString("errorCode");

				progressBar.setVisible(false);
				startSTTAdButton.setEnabled(true);
				JOptionPane.showMessageDialog(panelMain, "statusCode:" + statusCode + ", errorCode:" + errorCode + ", STT 고도화 로 변환요청 중 에러가 발생하였습니다.", "Warning", JOptionPane.WARNING_MESSAGE);
			}
		} catch (Exception e) {
			progressBar.setVisible(false);
			startSTTAdButton.setEnabled(true);
			startQueryButton.setEnabled(true);
			JOptionPane.showMessageDialog(panelMain, "STT 고도화로 변환요청 중 에러가 발생하였습니다.", "Warning", JOptionPane.WARNING_MESSAGE);
		}
	}
}
