package com.kt.ktAiApiClient;

import static javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER;
import static javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED;
import static javax.swing.SwingConstants.CENTER;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JSlider;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import org.json.JSONObject;

import kt.gigagenie.ai.api.VSTTS;

public class VsttsRestViewer extends JFrame {
	private JPanel panelMain;
	private JLabel mainLabel;
	private JProgressBar progressBar;
	private JButton startButton;
	private JTextArea taskOutput;
	private JScrollPane scrollPane;
	private JComboBox encodingList;
	private JComboBox channelList;
	private JComboBox sampleRateList;
	private JComboBox sampleFmtList;
	private JComboBox langList;
	private JComboBox emotionList;

	private JLabel pitchLbl;
	private JLabel speakerLbl;
	private JLabel speedLbl;
	private JLabel volumeLbl;
	private JLabel voiceNameLbl;
	private JLabel encodingLbl;
	private JLabel channelLbl;
	private JLabel emotionLbl;
	private JLabel sampleRateLbl;
	private JLabel sampleFmtLbl;
	private JLabel langLbl;

	private JSlider pitchSlider;
	private JSlider speakerSlider;
	private JSlider speedSlider;
	private JSlider volumeSlider;
	private VSTTS mVsTts = null;

	static final int LEVEL_MIN = 50;
	static final int LEVEL_MAX = 150;
	static final int LEVEL_INIT = 100;

	public VsttsRestViewer() {
		super("Vstts Rest API DEMO");

		createUIComponents();

		JComponent newContentPane = panelMain;
		newContentPane.setOpaque(true); // content panes must be opaque
		setContentPane(newContentPane);

		setResizable(false);
		setMinimumSize(new Dimension(1024, 768));
		setSize(1024, 768);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent wEvent) {
				if (mVsTts != null) {
					mVsTts = null;
				}
				System.exit(0);
			}
		});

		pack();
		setVisible(true);

		if (mVsTts == null) {
			mVsTts = new VSTTS();
			String strUrl = "https://" + ENV.hostname + ":" + ENV.ai_api_http_port;
			mVsTts.setServiceURL(strUrl);
			mVsTts.setAuth(ENV.client_key, ENV.client_id, ENV.client_secret);
		}
	}

	/**
	 * Create the GUI and show it. As with all GUI code, this must run on the event-dispatching thread.
	 */
	private static void createAndShowGUI() {
		// Create and set up the window.
		VsttsRestViewer viewer = new VsttsRestViewer();
	}

	public static void main(String[] args) {
		// Schedule a job for the event-dispatching thread:
		// creating and showing this application's GUI.
		SwingUtilities.invokeLater(() -> {
			createAndShowGUI();
		});
	}

	private void createUIComponents() {
		// Create the demo's UI.
		panelMain = new JPanel();
		mainLabel = new JLabel("VSTTS Rest API DEMO");
		mainLabel.setSize(50, 50);
		mainLabel.setHorizontalAlignment(CENTER);

		taskOutput = new JTextArea(5, 20);
		taskOutput.setToolTipText("VSTTS로 변환할 문자 입력");
		taskOutput.setMargin(new Insets(5, 5, 5, 5));
		taskOutput.setEditable(true);
		taskOutput.setCursor(null); // inherit the panel's cursor
		taskOutput.setLineWrap(true);

		scrollPane = new JScrollPane(taskOutput, VERTICAL_SCROLLBAR_AS_NEEDED, HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane.setAutoscrolls(true);

		JPanel controlPanel = new JPanel();
		controlPanel.setLayout(new GridLayout(12, 1));
		speakerLbl = new JLabel("speaker [100]", JLabel.CENTER);
		speakerLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

		speakerSlider = new JSlider(JSlider.HORIZONTAL, LEVEL_MIN, LEVEL_MAX, LEVEL_INIT);
		// Turn on labels at major tick marks.
		speakerSlider.setMajorTickSpacing(50);
		speakerSlider.setPaintTicks(true);
		speakerSlider.setPaintLabels(true);
		speakerSlider.addChangeListener(new ChangeListener() {
			@Override
			public void stateChanged(ChangeEvent e) {
				JSlider source = (JSlider) e.getSource();
				if (!source.getValueIsAdjusting()) {
					int level = (int) source.getValue();
					speakerLbl.setText("speaker [" + level + "]");
				}
			}
		});
		controlPanel.add(speakerLbl);
		controlPanel.add(speakerSlider);

		pitchLbl = new JLabel("pitch [100]", JLabel.CENTER);
		pitchLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

		pitchSlider = new JSlider(JSlider.HORIZONTAL, LEVEL_MIN - 1, LEVEL_MAX, LEVEL_INIT);
		// Turn on labels at major tick marks.
		pitchSlider.setMajorTickSpacing(50);
		pitchSlider.setPaintTicks(true);
		pitchSlider.setPaintLabels(true);
		pitchSlider.addChangeListener(new ChangeListener() {
			@Override
			public void stateChanged(ChangeEvent e) {
				JSlider source = (JSlider) e.getSource();
				if (!source.getValueIsAdjusting()) {
					int level = (int) source.getValue();
					pitchLbl.setText("pitch [" + level + "]");
				}
			}
		});

		controlPanel.add(pitchLbl);
		controlPanel.add(pitchSlider);

		speedLbl = new JLabel("speed [100]", JLabel.CENTER);
		speedLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

		speedSlider = new JSlider(JSlider.HORIZONTAL, LEVEL_MIN - 1, LEVEL_MAX, LEVEL_INIT);
		// Turn on labels at major tick marks.
		speedSlider.setMajorTickSpacing(50);
		speedSlider.setPaintTicks(true);
		speedSlider.setPaintLabels(true);
		speedSlider.addChangeListener(new ChangeListener() {
			@Override
			public void stateChanged(ChangeEvent e) {
				JSlider source = (JSlider) e.getSource();
				if (!source.getValueIsAdjusting()) {
					int level = (int) source.getValue();
					speedLbl.setText("speed [" + level + "]");
				}
			}
		});

		controlPanel.add(speedLbl);
		controlPanel.add(speedSlider);

		volumeLbl = new JLabel("volume [100]", JLabel.CENTER);
		volumeLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

		volumeSlider = new JSlider(JSlider.HORIZONTAL, LEVEL_MIN - 1, LEVEL_MAX, LEVEL_INIT);
		// Turn on labels at major tick marks.
		volumeSlider.setMajorTickSpacing(50);
		volumeSlider.setPaintTicks(true);
		volumeSlider.setPaintLabels(true);
		volumeSlider.addChangeListener(new ChangeListener() {
			@Override
			public void stateChanged(ChangeEvent e) {
				JSlider source = (JSlider) e.getSource();
				if (!source.getValueIsAdjusting()) {
					int level = (int) source.getValue();
					volumeLbl.setText("volume [" + level + "]");
				}
			}
		});

		controlPanel.add(volumeLbl);
		controlPanel.add(volumeSlider);

		String[] langStrings = { "ko" };

		langLbl = new JLabel("language", JLabel.CENTER);
		langLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

		langList = new JComboBox(langStrings);
		langList.setSelectedIndex(0);

		controlPanel.add(langLbl);
		controlPanel.add(langList);

		String[] emotionStrings = { "neutral", "happy", "angry", "calm", "sleepy", "sad", "excited", "fear", "disappointed" };

		emotionLbl = new JLabel("emotion", JLabel.CENTER);
		emotionLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

		emotionList = new JComboBox(emotionStrings);
		langList.setSelectedIndex(0);

		controlPanel.add(emotionLbl);
		controlPanel.add(emotionList);

		String[] sampleRateStrings = { "16000", "8000", "24000", "44100", "48000" };

		sampleRateLbl = new JLabel("sampleRate", JLabel.CENTER);
		sampleRateLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

		sampleRateList = new JComboBox(sampleRateStrings);
		sampleRateList.setSelectedIndex(0);

		controlPanel.add(sampleRateLbl);
		controlPanel.add(sampleRateList);

		String[] sampleFmtStrings = { "S16LE", "F32LE" };

		sampleFmtLbl = new JLabel("sampleFmt", JLabel.CENTER);
		sampleFmtLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

		sampleFmtList = new JComboBox(sampleFmtStrings);
		sampleFmtList.setSelectedIndex(0);

		controlPanel.add(sampleFmtLbl);
		controlPanel.add(sampleFmtList);

		voiceNameLbl = new JLabel("voiceName", JLabel.CENTER);
		voiceNameLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

		JTextField voiceNameText = new JTextField();

		controlPanel.add(voiceNameLbl);
		controlPanel.add(voiceNameText);

		String[] encodingStrings = { "wav", "mp3" };

		encodingLbl = new JLabel("encoding", JLabel.CENTER);
		encodingLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

		encodingList = new JComboBox(encodingStrings);
		encodingList.setSelectedIndex(0);
		encodingList.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				JComboBox cb = (JComboBox) e.getSource();
				if (cb.getSelectedIndex() == 1) {
					channelLbl.setVisible(false);
					channelList.setVisible(false);
					sampleRateLbl.setVisible(false);
					sampleRateList.setVisible(false);
					sampleFmtLbl.setVisible(false);
					sampleFmtList.setVisible(false);
				} else {
					channelLbl.setVisible(true);
					channelList.setVisible(true);
					sampleRateLbl.setVisible(true);
					sampleRateList.setVisible(true);
					sampleFmtLbl.setVisible(true);
					sampleFmtList.setVisible(true);
				}
			}
		});
		controlPanel.add(encodingLbl);
		controlPanel.add(encodingList);

		String[] channelStrings = { "1", "2" };

		channelLbl = new JLabel("channel", JLabel.CENTER);
		channelLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

		channelList = new JComboBox(channelStrings);
		channelList.setSelectedIndex(0);

		controlPanel.add(channelLbl);
		controlPanel.add(channelList);

		controlPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		controlPanel.setPreferredSize(new Dimension(300, 300));
		taskOutput.setText("안녕하세요. 보이스 스튜디오입니다.");

		startButton = new JButton("VSTTS Request");
		startButton.setActionCommand("start");
		startButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				mVsTts.setAuth(ENV.client_key, ENV.client_id, ENV.client_secret);
				String input = taskOutput.getText();

				progressBar.setVisible(true);

				int pitch = pitchSlider.getValue();
				int speed = speedSlider.getValue();
				int speaker = speakerSlider.getValue();
				int volume = volumeSlider.getValue();
				String language = (String) langList.getSelectedItem();
				String encoding = (String) encodingList.getSelectedItem();
				int channel = Integer.parseInt((String) channelList.getSelectedItem());
				int sampleRate = Integer.parseInt((String) sampleRateList.getSelectedItem());
				String sampleFmt = (String) sampleFmtList.getSelectedItem();
				String emotion = (String) emotionList.getSelectedItem();
				String voiceName = voiceNameText.getText();

				sendText(input, pitch, speed, speaker, volume, language, encoding, channel, sampleRate, sampleFmt, emotion, voiceName);
			}
		});

		progressBar = new JProgressBar();
		progressBar.setIndeterminate(true);
		progressBar.setVisible(false);

		JPanel bottomPanel = new JPanel();
		bottomPanel.add(startButton);
		bottomPanel.add(progressBar);

		panelMain.setLayout(new BorderLayout());
		panelMain.add(mainLabel, BorderLayout.NORTH);
		panelMain.add(scrollPane, BorderLayout.CENTER);
		panelMain.add(controlPanel, BorderLayout.EAST);
		panelMain.add(bottomPanel, BorderLayout.SOUTH);
		panelMain.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
	}

	private void sendText(final String text, final int pitch, final int speed, final int speaker, final int volume, final String language, final String encoding, final int channel,
			final int sampleRate, final String sampleFmt, final String emotion, final String voiceName) {
		new Thread(new Runnable() {
			@Override
			public void run() {
				try {
					JSONObject resultJson = mVsTts.requestVSTTS(text, pitch, speed, speaker, volume, language, encoding, channel, sampleRate, sampleFmt, emotion, voiceName);

					int statusCode = resultJson.optInt("statusCode");

					if (statusCode == 200) {
						byte[] audioData = (byte[]) resultJson.opt("audioData");

						String targetFilePath = System.getProperty("user.dir") + "\\" + "Vstts.mp3";

						FileOutputStream fos = null;
						try {
							fos = new FileOutputStream(targetFilePath);
						} catch (FileNotFoundException e) {
							e.printStackTrace();
						}

						try {
							fos.write(audioData, 0, audioData.length);
							fos.close();
							JOptionPane.showMessageDialog(panelMain, targetFilePath + "에 파일이 저장되었습니다.", "Information", JOptionPane.INFORMATION_MESSAGE);
						} catch (IOException e) {
							e.printStackTrace();
						}

						progressBar.setVisible(false);
					} else {
						progressBar.setVisible(false);

						String errorCode = resultJson.optString("errorCode");

						JOptionPane.showMessageDialog(panelMain, "statusCode:" + statusCode + ", errorCode:" + errorCode + ", VsTTS로 변환요청 중 에러가 발생하였습니다.", "Warning", JOptionPane.WARNING_MESSAGE);
					}
				} catch (Exception e) {

				}
			}
		}).start();
	}
}
